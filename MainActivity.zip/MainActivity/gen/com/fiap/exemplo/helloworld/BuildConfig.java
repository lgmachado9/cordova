/** Automatically generated file. DO NOT MODIFY */
package com.fiap.exemplo.helloworld;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}